package com.example.projetapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetappApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProjetappApplication.class, args);
    }
}
